# Site de Consultoria

Site institucional premium em HTML, CSS e JavaScript puro, pronto para publicação na Vercel.

## Estrutura

- `index.html` — conteúdo e estrutura
- `css/style.css` — identidade visual e responsividade
- `js/script.js` — menu, modal, animações e configurações de integrações
- `assets/` — favicon e imagem Open Graph de placeholder

## Antes de publicar

Edite principalmente:
1. Nome/logo da empresa em `index.html`.
2. Conteúdo marcado como `PLACEHOLDER`.
3. Contatos, foto, cases e depoimentos.
4. Objeto `CONFIG` em `js/script.js`:
   - `bookingUrl`
   - `whatsappNumber`
   - `instagramUrl`
   - `linkedinUrl`
   - `formEndpoint`

## Publicação na Vercel

1. Suba esta pasta para um repositório no GitHub.
2. Na Vercel, importe o repositório.
3. Framework Preset: Other.
4. Build Command: deixe vazio.
5. Output Directory: `.`
6. Deploy.

Como não há backend, o formulário permanece preparado para futura integração com um endpoint/CRM. O site em si funciona como página estática.

## Checklist

- Menu com âncoras internas.
- Responsividade mobile/tablet/desktop.
- SEO básico e Open Graph.
- Favicon.
- Acessibilidade básica.
- Respeito a `prefers-reduced-motion`.
- Sem bibliotecas externas obrigatórias.
- Sem imagens de terceiros protegidas por direitos autorais.
