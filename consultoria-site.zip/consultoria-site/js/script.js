/* CONFIGURAÇÕES — SUBSTITUA SOMENTE OS VALORES ABAIXO */
const CONFIG = {
  bookingUrl: "", // Ex.: https://calendly.com/suaempresa/reuniao
  whatsappNumber: "", // somente números, com DDI e DDD. Ex.: 5511999999999
  instagramUrl: "",
  linkedinUrl: "",
  formEndpoint: "" // endpoint futuro do formulário/CRM
};

document.addEventListener("DOMContentLoaded", () => {
  const menuButton = document.querySelector(".menu-toggle");
  const menu = document.querySelector(".main-nav");

  menuButton?.addEventListener("click", () => {
    const open = menu.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
  });

  menu?.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      menu.classList.remove("open");
      menuButton?.setAttribute("aria-expanded", "false");
    });
  });

  document.querySelectorAll("[data-booking]").forEach(el => {
    el.addEventListener("click", e => {
      if (!CONFIG.bookingUrl) {
        e.preventDefault();
        alert("PLACEHOLDER: configure o link de agendamento em js/script.js.");
        return;
      }
      el.href = CONFIG.bookingUrl;
      el.target = "_blank";
      el.rel = "noopener";
    });
  });

  document.querySelectorAll("[data-whatsapp]").forEach(el => {
    el.addEventListener("click", e => {
      if (!CONFIG.whatsappNumber) {
        e.preventDefault();
        alert("PLACEHOLDER: configure o número do WhatsApp em js/script.js.");
        return;
      }
      el.href = `https://wa.me/${CONFIG.whatsappNumber}`;
      el.target = "_blank";
      el.rel = "noopener";
    });
  });

  document.querySelectorAll("[data-social]").forEach(el => {
    const text = el.textContent.trim().toLowerCase();
    const url = text.includes("instagram") ? CONFIG.instagramUrl : CONFIG.linkedinUrl;
    if (url) { el.href = url; el.target = "_blank"; el.rel = "noopener"; }
  });

  const modal = document.querySelector("#service-modal");
  const modalTitle = document.querySelector("#modal-title");
  document.querySelectorAll(".service-more").forEach(button => {
    button.addEventListener("click", () => {
      modalTitle.textContent = button.dataset.service || "Serviço";
      modal.classList.add("is-open");
      modal.setAttribute("aria-hidden", "false");
    });
  });
  document.querySelectorAll("[data-close]").forEach(el => el.addEventListener("click", () => {
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
  }));
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      modal.classList.remove("is-open");
      modal.setAttribute("aria-hidden", "true");
    }
  });

  const form = document.querySelector("#lead-form");
  const status = document.querySelector("#form-status");
  form?.addEventListener("submit", async e => {
    e.preventDefault();
    if (!CONFIG.formEndpoint) {
      status.textContent = "PLACEHOLDER: formulário pronto para integração. Configure CONFIG.formEndpoint em js/script.js.";
      return;
    }
    status.textContent = "Enviando...";
    try {
      const response = await fetch(CONFIG.formEndpoint, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(Object.fromEntries(new FormData(form)))
      });
      if (!response.ok) throw new Error("Falha no envio");
      form.reset();
      status.textContent = "Mensagem enviada com sucesso.";
    } catch {
      status.textContent = "Não foi possível enviar agora. Tente novamente ou use o WhatsApp.";
    }
  });

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, {threshold: .12});
  document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

  document.querySelector("#year").textContent = new Date().getFullYear();
});
